# Vector Database

## Description

This package is aiming to make python users to build their own vector database of diverse types of data. 

This package is in building process and will be released stable version soon.

## Try Alpha Version

```python
import vector_database.embdding as emb

image_embdding = emb.ImageEmbdding()
image_embdding.imageVectorDatabaseBuild('path/to/image_folder')
image_embedding.imageQuery()
```
